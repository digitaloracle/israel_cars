(function () {
  const STYLE_ID = 'ivl-dealer-filter';

  // Target any listing card (<a>) that contains a dealer agency name label.
  // yad2 uses different <a> class names across pages (ultra-plus_box, agency-item_box, etc.)
  // but all dealer cards consistently contain [class*="agencyNameBox"] inside them.
  const CSS = 'a:has([class*="agencyNameBox"]) { display: none !important; }';

  function ensureStyle() {
    if (!document.getElementById(STYLE_ID)) {
      const style = document.createElement('style');
      style.id = STYLE_ID;
      style.textContent = CSS;
      document.head.appendChild(style);
    }
  }

  ensureStyle();

  // Re-add if Next.js removes it during SPA (client-side) navigation.
  new MutationObserver(ensureStyle).observe(document.head, { childList: true });
})();
